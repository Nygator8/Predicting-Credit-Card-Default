

```python
import numpy as np
import pandas as pd
import scipy
from math import sqrt
import matplotlib.pyplot as plt
```


```python
import numpy as np
```


```python
import math as mt
```


```python
from numpy import random
```


```python
#estimators
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn import linear_model
```


```python
import math
```


```python
#model metrics
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.model_selection import cross_val_score
```


```python
credit = pd.read_csv('default of credit card clients.csv', header =1)
```


```python
#cross validation
from sklearn.model_selection import train_test_split
```


```python
credit.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>LIMIT_BAL</th>
      <th>SEX</th>
      <th>EDUCATION</th>
      <th>MARRIAGE</th>
      <th>AGE</th>
      <th>PAY_0</th>
      <th>PAY_2</th>
      <th>PAY_3</th>
      <th>PAY_4</th>
      <th>...</th>
      <th>BILL_AMT4</th>
      <th>BILL_AMT5</th>
      <th>BILL_AMT6</th>
      <th>PAY_AMT1</th>
      <th>PAY_AMT2</th>
      <th>PAY_AMT3</th>
      <th>PAY_AMT4</th>
      <th>PAY_AMT5</th>
      <th>PAY_AMT6</th>
      <th>default payment next month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>20000</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>24</td>
      <td>2</td>
      <td>2</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>689</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>120000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>26</td>
      <td>-1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3272</td>
      <td>3455</td>
      <td>3261</td>
      <td>0</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>0</td>
      <td>2000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>90000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>34</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>14331</td>
      <td>14948</td>
      <td>15549</td>
      <td>1518</td>
      <td>1500</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>5000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>50000</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>37</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>28314</td>
      <td>28959</td>
      <td>29547</td>
      <td>2000</td>
      <td>2019</td>
      <td>1200</td>
      <td>1100</td>
      <td>1069</td>
      <td>1000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>50000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>57</td>
      <td>-1</td>
      <td>0</td>
      <td>-1</td>
      <td>0</td>
      <td>...</td>
      <td>20940</td>
      <td>19146</td>
      <td>19131</td>
      <td>2000</td>
      <td>36681</td>
      <td>10000</td>
      <td>9000</td>
      <td>689</td>
      <td>679</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 25 columns</p>
</div>




```python
credit.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>LIMIT_BAL</th>
      <th>SEX</th>
      <th>EDUCATION</th>
      <th>MARRIAGE</th>
      <th>AGE</th>
      <th>PAY_0</th>
      <th>PAY_2</th>
      <th>PAY_3</th>
      <th>PAY_4</th>
      <th>...</th>
      <th>BILL_AMT4</th>
      <th>BILL_AMT5</th>
      <th>BILL_AMT6</th>
      <th>PAY_AMT1</th>
      <th>PAY_AMT2</th>
      <th>PAY_AMT3</th>
      <th>PAY_AMT4</th>
      <th>PAY_AMT5</th>
      <th>PAY_AMT6</th>
      <th>default payment next month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>...</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>3.000000e+04</td>
      <td>30000.00000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
      <td>30000.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>15000.500000</td>
      <td>167484.322667</td>
      <td>1.603733</td>
      <td>1.853133</td>
      <td>1.551867</td>
      <td>35.485500</td>
      <td>-0.016700</td>
      <td>-0.133767</td>
      <td>-0.166200</td>
      <td>-0.220667</td>
      <td>...</td>
      <td>43262.948967</td>
      <td>40311.400967</td>
      <td>38871.760400</td>
      <td>5663.580500</td>
      <td>5.921163e+03</td>
      <td>5225.68150</td>
      <td>4826.076867</td>
      <td>4799.387633</td>
      <td>5215.502567</td>
      <td>0.221200</td>
    </tr>
    <tr>
      <th>std</th>
      <td>8660.398374</td>
      <td>129747.661567</td>
      <td>0.489129</td>
      <td>0.790349</td>
      <td>0.521970</td>
      <td>9.217904</td>
      <td>1.123802</td>
      <td>1.197186</td>
      <td>1.196868</td>
      <td>1.169139</td>
      <td>...</td>
      <td>64332.856134</td>
      <td>60797.155770</td>
      <td>59554.107537</td>
      <td>16563.280354</td>
      <td>2.304087e+04</td>
      <td>17606.96147</td>
      <td>15666.159744</td>
      <td>15278.305679</td>
      <td>17777.465775</td>
      <td>0.415062</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>10000.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>21.000000</td>
      <td>-2.000000</td>
      <td>-2.000000</td>
      <td>-2.000000</td>
      <td>-2.000000</td>
      <td>...</td>
      <td>-170000.000000</td>
      <td>-81334.000000</td>
      <td>-339603.000000</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
      <td>0.00000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>7500.750000</td>
      <td>50000.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>28.000000</td>
      <td>-1.000000</td>
      <td>-1.000000</td>
      <td>-1.000000</td>
      <td>-1.000000</td>
      <td>...</td>
      <td>2326.750000</td>
      <td>1763.000000</td>
      <td>1256.000000</td>
      <td>1000.000000</td>
      <td>8.330000e+02</td>
      <td>390.00000</td>
      <td>296.000000</td>
      <td>252.500000</td>
      <td>117.750000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>15000.500000</td>
      <td>140000.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>34.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>19052.000000</td>
      <td>18104.500000</td>
      <td>17071.000000</td>
      <td>2100.000000</td>
      <td>2.009000e+03</td>
      <td>1800.00000</td>
      <td>1500.000000</td>
      <td>1500.000000</td>
      <td>1500.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>22500.250000</td>
      <td>240000.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>2.000000</td>
      <td>41.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>54506.000000</td>
      <td>50190.500000</td>
      <td>49198.250000</td>
      <td>5006.000000</td>
      <td>5.000000e+03</td>
      <td>4505.00000</td>
      <td>4013.250000</td>
      <td>4031.500000</td>
      <td>4000.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>30000.000000</td>
      <td>1000000.000000</td>
      <td>2.000000</td>
      <td>6.000000</td>
      <td>3.000000</td>
      <td>79.000000</td>
      <td>8.000000</td>
      <td>8.000000</td>
      <td>8.000000</td>
      <td>8.000000</td>
      <td>...</td>
      <td>891586.000000</td>
      <td>927171.000000</td>
      <td>961664.000000</td>
      <td>873552.000000</td>
      <td>1.684259e+06</td>
      <td>896040.00000</td>
      <td>621000.000000</td>
      <td>426529.000000</td>
      <td>528666.000000</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 25 columns</p>
</div>




```python
credit.isnull
```




    <bound method DataFrame.isnull of           ID  LIMIT_BAL  SEX  EDUCATION  MARRIAGE  AGE  PAY_0  PAY_2  PAY_3  \
    0          1      20000    2          2         1   24      2      2     -1   
    1          2     120000    2          2         2   26     -1      2      0   
    2          3      90000    2          2         2   34      0      0      0   
    3          4      50000    2          2         1   37      0      0      0   
    4          5      50000    1          2         1   57     -1      0     -1   
    5          6      50000    1          1         2   37      0      0      0   
    6          7     500000    1          1         2   29      0      0      0   
    7          8     100000    2          2         2   23      0     -1     -1   
    8          9     140000    2          3         1   28      0      0      2   
    9         10      20000    1          3         2   35     -2     -2     -2   
    10        11     200000    2          3         2   34      0      0      2   
    11        12     260000    2          1         2   51     -1     -1     -1   
    12        13     630000    2          2         2   41     -1      0     -1   
    13        14      70000    1          2         2   30      1      2      2   
    14        15     250000    1          1         2   29      0      0      0   
    15        16      50000    2          3         3   23      1      2      0   
    16        17      20000    1          1         2   24      0      0      2   
    17        18     320000    1          1         1   49      0      0      0   
    18        19     360000    2          1         1   49      1     -2     -2   
    19        20     180000    2          1         2   29      1     -2     -2   
    20        21     130000    2          3         2   39      0      0      0   
    21        22     120000    2          2         1   39     -1     -1     -1   
    22        23      70000    2          2         2   26      2      0      0   
    23        24     450000    2          1         1   40     -2     -2     -2   
    24        25      90000    1          1         2   23      0      0      0   
    25        26      50000    1          3         2   23      0      0      0   
    26        27      60000    1          1         2   27      1     -2     -1   
    27        28      50000    2          3         2   30      0      0      0   
    28        29      50000    2          3         1   47     -1     -1     -1   
    29        30      50000    1          1         2   26      0      0      0   
    ...      ...        ...  ...        ...       ...  ...    ...    ...    ...   
    29970  29971     360000    1          1         1   34     -1     -1     -1   
    29971  29972      80000    1          3         1   36      0      0      0   
    29972  29973     190000    1          1         1   37      0      0      0   
    29973  29974     230000    1          2         1   35      1     -2     -2   
    29974  29975      50000    1          2         1   37      1      2      2   
    29975  29976     220000    1          2         1   41      0      0     -1   
    29976  29977      40000    1          2         2   47      2      2      3   
    29977  29978     420000    1          1         2   34      0      0      0   
    29978  29979     310000    1          2         1   39      0      0      0   
    29979  29980     180000    1          1         1   32     -2     -2     -2   
    29980  29981      50000    1          3         2   42      0      0      0   
    29981  29982      50000    1          2         1   44      1      2      2   
    29982  29983      90000    1          2         1   36      0      0      0   
    29983  29984      20000    1          2         1   44     -2     -2     -2   
    29984  29985      30000    1          2         2   38     -1     -1     -2   
    29985  29986     240000    1          1         2   30     -2     -2     -2   
    29986  29987     360000    1          1         2   35     -1     -1     -2   
    29987  29988     130000    1          1         2   34      0      0      0   
    29988  29989     250000    1          1         1   34      0      0      0   
    29989  29990     150000    1          1         2   35     -1     -1     -1   
    29990  29991     140000    1          2         1   41      0      0      0   
    29991  29992     210000    1          2         1   34      3      2      2   
    29992  29993      10000    1          3         1   43      0      0      0   
    29993  29994     100000    1          1         2   38      0     -1     -1   
    29994  29995      80000    1          2         2   34      2      2      2   
    29995  29996     220000    1          3         1   39      0      0      0   
    29996  29997     150000    1          3         2   43     -1     -1     -1   
    29997  29998      30000    1          2         2   37      4      3      2   
    29998  29999      80000    1          3         1   41      1     -1      0   
    29999  30000      50000    1          2         1   46      0      0      0   
    
           PAY_4             ...              BILL_AMT4  BILL_AMT5  BILL_AMT6  \
    0         -1             ...                      0          0          0   
    1          0             ...                   3272       3455       3261   
    2          0             ...                  14331      14948      15549   
    3          0             ...                  28314      28959      29547   
    4          0             ...                  20940      19146      19131   
    5          0             ...                  19394      19619      20024   
    6          0             ...                 542653     483003     473944   
    7          0             ...                    221       -159        567   
    8          0             ...                  12211      11793       3719   
    9         -2             ...                      0      13007      13912   
    10         0             ...                   2513       1828       3731   
    11        -1             ...                   8517      22287      13668   
    12        -1             ...                   6500       6500       2870   
    13         0             ...                  66782      36137      36894   
    14         0             ...                  59696      56875      55512   
    15         0             ...                  28771      29531      30211   
    16         2             ...                  18338      17905      19104   
    17        -1             ...                  70074       5856     195599   
    18        -2             ...                      0          0          0   
    19        -2             ...                      0          0          0   
    20         0             ...                  20616      11802        930   
    21        -1             ...                      0        632        316   
    22         2             ...                  44006      46905      46012   
    23        -2             ...                    560          0          0   
    24        -1             ...                   5398       6360       8292   
    25         0             ...                  28967      29829      30046   
    26        -1             ...                    -57        127       -189   
    27         0             ...                  17878      18931      19617   
    28        -1             ...                   2040      30430        257   
    29         0             ...                  17907      18375      11400   
    ...      ...             ...                    ...        ...        ...   
    29970      0             ...                  49005       8676      19487   
    29971      0             ...                  69674      71070      73612   
    29972      0             ...                  29223      19616     148482   
    29973     -2             ...                      0          0          0   
    29974      2             ...                   2846       1585       1324   
    29975     -1             ...                   5924       1759       1824   
    29976      2             ...                  51259      47151      46934   
    29977      0             ...                 141695     144839     147954   
    29978      0             ...                 219409     216540     210675   
    29979     -2             ...                      0          0          0   
    29980      0             ...                  50360      19971      19694   
    29981      2             ...                  28192      22676      14647   
    29982      0             ...                  11328      12036      14329   
    29983     -2             ...                   2882       9235       1719   
    29984     -1             ...                   1993       1907       3319   
    29985     -2             ...                      0          0          0   
    29986     -2             ...                      0          0          0   
    29987      0             ...                 108047      93708      97353   
    29988      0             ...                 245750     175005     179687   
    29989     -1             ...                    780          0          0   
    29990      0             ...                 138262      49675      46121   
    29991      2             ...                   2500       2500       2500   
    29992     -2             ...                      0          0          0   
    29993      0             ...                  70626      69473      55004   
    29994      2             ...                  77519      82607      81158   
    29995      0             ...                  88004      31237      15980   
    29996     -1             ...                   8979       5190          0   
    29997     -1             ...                  20878      20582      19357   
    29998      0             ...                  52774      11855      48944   
    29999      0             ...                  36535      32428      15313   
    
           PAY_AMT1  PAY_AMT2  PAY_AMT3  PAY_AMT4  PAY_AMT5  PAY_AMT6  \
    0             0       689         0         0         0         0   
    1             0      1000      1000      1000         0      2000   
    2          1518      1500      1000      1000      1000      5000   
    3          2000      2019      1200      1100      1069      1000   
    4          2000     36681     10000      9000       689       679   
    5          2500      1815       657      1000      1000       800   
    6         55000     40000     38000     20239     13750     13770   
    7           380       601         0       581      1687      1542   
    8          3329         0       432      1000      1000      1000   
    9             0         0         0     13007      1122         0   
    10         2306        12        50       300      3738        66   
    11        21818      9966      8583     22301         0      3640   
    12         1000      6500      6500      6500      2870         0   
    13         3200         0      3000      3000      1500         0   
    14         3000      3000      3000      3000      3000      3000   
    15            0      1500      1100      1200      1300      1100   
    16         3200         0      1500         0      1650         0   
    17        10358     10000     75940     20000    195599     50000   
    18            0         0         0         0         0         0   
    19            0         0         0         0         0         0   
    20         3000      1537      1000      2000       930     33764   
    21          316       316         0       632       316         0   
    22         2007      3582         0      3601         0      1820   
    23        19428      1473       560         0         0      1128   
    24         5757         0      5398      1200      2045      2000   
    25         1973      1426      1001      1432      1062       997   
    26            0      1000         0       500         0      1000   
    27         1300      1300      1000      1500      1000      1012   
    28         3415      3421      2044     30430       257         0   
    29         1500      1500      1000      1000      1600         0   
    ...         ...       ...       ...       ...       ...       ...   
    29970     52951     64535      8907        53     19584     16080   
    29971      2395      2500      2530      2556      3700      3000   
    29972      2000      3869     25128     10115    148482      4800   
    29973         0         0         0         0         0         0   
    29974         0      3000         0         0      1000      1000   
    29975      8840      6643      5924      1759      1824      7022   
    29976      4000         0      2000         0      3520         0   
    29977      7000      7000      5500      5500      5600      5000   
    29978     10029      9218     10029      8049      8040     10059   
    29979         0         0         0         0         0         0   
    29980     10000      4000      5000      3000      4500      2000   
    29981      2300      1700         0       517       503       585   
    29982      1500      1500      1500      1200      2500         0   
    29983      2890      2720      2890      9263      1824      1701   
    29984       923      2977      1999      3057      3319      1000   
    29985         0         0         0         0         0         0   
    29986         0         0         0         0         0         0   
    29987      3000      2000     93000      4000      5027      4005   
    29988     65000      8800      9011      6000      7000      6009   
    29989      9054         0       783         0         0         0   
    29990      6000      7000      4228      1505      2000      2000   
    29991         0         0         0         0         0         0   
    29992      2000         0         0         0         0         0   
    29993      2000    111784      4000      3000      2000      2000   
    29994      7000      3500         0      7000         0      4000   
    29995      8500     20000      5003      3047      5000      1000   
    29996      1837      3526      8998       129         0         0   
    29997         0         0     22000      4200      2000      3100   
    29998     85900      3409      1178      1926     52964      1804   
    29999      2078      1800      1430      1000      1000      1000   
    
           default payment next month  
    0                               1  
    1                               1  
    2                               0  
    3                               0  
    4                               0  
    5                               0  
    6                               0  
    7                               0  
    8                               0  
    9                               0  
    10                              0  
    11                              0  
    12                              0  
    13                              1  
    14                              0  
    15                              0  
    16                              1  
    17                              0  
    18                              0  
    19                              0  
    20                              0  
    21                              1  
    22                              1  
    23                              1  
    24                              0  
    25                              0  
    26                              1  
    27                              0  
    28                              0  
    29                              0  
    ...                           ...  
    29970                           0  
    29971                           0  
    29972                           0  
    29973                           1  
    29974                           1  
    29975                           0  
    29976                           1  
    29977                           0  
    29978                           0  
    29979                           0  
    29980                           0  
    29981                           0  
    29982                           1  
    29983                           0  
    29984                           0  
    29985                           0  
    29986                           0  
    29987                           0  
    29988                           0  
    29989                           0  
    29990                           0  
    29991                           1  
    29992                           0  
    29993                           0  
    29994                           1  
    29995                           0  
    29996                           0  
    29997                           1  
    29998                           1  
    29999                           1  
    
    [30000 rows x 25 columns]>




```python
credit.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 30000 entries, 0 to 29999
    Data columns (total 25 columns):
    ID                            30000 non-null int64
    LIMIT_BAL                     30000 non-null int64
    SEX                           30000 non-null int64
    EDUCATION                     30000 non-null int64
    MARRIAGE                      30000 non-null int64
    AGE                           30000 non-null int64
    PAY_0                         30000 non-null int64
    PAY_2                         30000 non-null int64
    PAY_3                         30000 non-null int64
    PAY_4                         30000 non-null int64
    PAY_5                         30000 non-null int64
    PAY_6                         30000 non-null int64
    BILL_AMT1                     30000 non-null int64
    BILL_AMT2                     30000 non-null int64
    BILL_AMT3                     30000 non-null int64
    BILL_AMT4                     30000 non-null int64
    BILL_AMT5                     30000 non-null int64
    BILL_AMT6                     30000 non-null int64
    PAY_AMT1                      30000 non-null int64
    PAY_AMT2                      30000 non-null int64
    PAY_AMT3                      30000 non-null int64
    PAY_AMT4                      30000 non-null int64
    PAY_AMT5                      30000 non-null int64
    PAY_AMT6                      30000 non-null int64
    default payment next month    30000 non-null int64
    dtypes: int64(25)
    memory usage: 5.7 MB



```python
#Convert to dataframe
df_credit = pd.DataFrame(credit)
```


```python
df_credit
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>LIMIT_BAL</th>
      <th>SEX</th>
      <th>EDUCATION</th>
      <th>MARRIAGE</th>
      <th>AGE</th>
      <th>PAY_0</th>
      <th>PAY_2</th>
      <th>PAY_3</th>
      <th>PAY_4</th>
      <th>...</th>
      <th>BILL_AMT4</th>
      <th>BILL_AMT5</th>
      <th>BILL_AMT6</th>
      <th>PAY_AMT1</th>
      <th>PAY_AMT2</th>
      <th>PAY_AMT3</th>
      <th>PAY_AMT4</th>
      <th>PAY_AMT5</th>
      <th>PAY_AMT6</th>
      <th>default payment next month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>20000</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>24</td>
      <td>2</td>
      <td>2</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>689</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>120000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>26</td>
      <td>-1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3272</td>
      <td>3455</td>
      <td>3261</td>
      <td>0</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>0</td>
      <td>2000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>90000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>34</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>14331</td>
      <td>14948</td>
      <td>15549</td>
      <td>1518</td>
      <td>1500</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>5000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>50000</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>37</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>28314</td>
      <td>28959</td>
      <td>29547</td>
      <td>2000</td>
      <td>2019</td>
      <td>1200</td>
      <td>1100</td>
      <td>1069</td>
      <td>1000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>50000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>57</td>
      <td>-1</td>
      <td>0</td>
      <td>-1</td>
      <td>0</td>
      <td>...</td>
      <td>20940</td>
      <td>19146</td>
      <td>19131</td>
      <td>2000</td>
      <td>36681</td>
      <td>10000</td>
      <td>9000</td>
      <td>689</td>
      <td>679</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>50000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>37</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>19394</td>
      <td>19619</td>
      <td>20024</td>
      <td>2500</td>
      <td>1815</td>
      <td>657</td>
      <td>1000</td>
      <td>1000</td>
      <td>800</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>7</td>
      <td>500000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>29</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>542653</td>
      <td>483003</td>
      <td>473944</td>
      <td>55000</td>
      <td>40000</td>
      <td>38000</td>
      <td>20239</td>
      <td>13750</td>
      <td>13770</td>
      <td>0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>8</td>
      <td>100000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>23</td>
      <td>0</td>
      <td>-1</td>
      <td>-1</td>
      <td>0</td>
      <td>...</td>
      <td>221</td>
      <td>-159</td>
      <td>567</td>
      <td>380</td>
      <td>601</td>
      <td>0</td>
      <td>581</td>
      <td>1687</td>
      <td>1542</td>
      <td>0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>9</td>
      <td>140000</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>28</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>...</td>
      <td>12211</td>
      <td>11793</td>
      <td>3719</td>
      <td>3329</td>
      <td>0</td>
      <td>432</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>10</td>
      <td>20000</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>35</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>...</td>
      <td>0</td>
      <td>13007</td>
      <td>13912</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>13007</td>
      <td>1122</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>11</td>
      <td>200000</td>
      <td>2</td>
      <td>3</td>
      <td>2</td>
      <td>34</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>...</td>
      <td>2513</td>
      <td>1828</td>
      <td>3731</td>
      <td>2306</td>
      <td>12</td>
      <td>50</td>
      <td>300</td>
      <td>3738</td>
      <td>66</td>
      <td>0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>260000</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>51</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>8517</td>
      <td>22287</td>
      <td>13668</td>
      <td>21818</td>
      <td>9966</td>
      <td>8583</td>
      <td>22301</td>
      <td>0</td>
      <td>3640</td>
      <td>0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>13</td>
      <td>630000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>41</td>
      <td>-1</td>
      <td>0</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>6500</td>
      <td>6500</td>
      <td>2870</td>
      <td>1000</td>
      <td>6500</td>
      <td>6500</td>
      <td>6500</td>
      <td>2870</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>14</td>
      <td>70000</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>30</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>...</td>
      <td>66782</td>
      <td>36137</td>
      <td>36894</td>
      <td>3200</td>
      <td>0</td>
      <td>3000</td>
      <td>3000</td>
      <td>1500</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>14</th>
      <td>15</td>
      <td>250000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>29</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>59696</td>
      <td>56875</td>
      <td>55512</td>
      <td>3000</td>
      <td>3000</td>
      <td>3000</td>
      <td>3000</td>
      <td>3000</td>
      <td>3000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>16</td>
      <td>50000</td>
      <td>2</td>
      <td>3</td>
      <td>3</td>
      <td>23</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>28771</td>
      <td>29531</td>
      <td>30211</td>
      <td>0</td>
      <td>1500</td>
      <td>1100</td>
      <td>1200</td>
      <td>1300</td>
      <td>1100</td>
      <td>0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>17</td>
      <td>20000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>24</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>2</td>
      <td>...</td>
      <td>18338</td>
      <td>17905</td>
      <td>19104</td>
      <td>3200</td>
      <td>0</td>
      <td>1500</td>
      <td>0</td>
      <td>1650</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>17</th>
      <td>18</td>
      <td>320000</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>49</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>-1</td>
      <td>...</td>
      <td>70074</td>
      <td>5856</td>
      <td>195599</td>
      <td>10358</td>
      <td>10000</td>
      <td>75940</td>
      <td>20000</td>
      <td>195599</td>
      <td>50000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>360000</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>49</td>
      <td>1</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>20</td>
      <td>180000</td>
      <td>2</td>
      <td>1</td>
      <td>2</td>
      <td>29</td>
      <td>1</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>20</th>
      <td>21</td>
      <td>130000</td>
      <td>2</td>
      <td>3</td>
      <td>2</td>
      <td>39</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>20616</td>
      <td>11802</td>
      <td>930</td>
      <td>3000</td>
      <td>1537</td>
      <td>1000</td>
      <td>2000</td>
      <td>930</td>
      <td>33764</td>
      <td>0</td>
    </tr>
    <tr>
      <th>21</th>
      <td>22</td>
      <td>120000</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>39</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>0</td>
      <td>632</td>
      <td>316</td>
      <td>316</td>
      <td>316</td>
      <td>0</td>
      <td>632</td>
      <td>316</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>22</th>
      <td>23</td>
      <td>70000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>26</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>...</td>
      <td>44006</td>
      <td>46905</td>
      <td>46012</td>
      <td>2007</td>
      <td>3582</td>
      <td>0</td>
      <td>3601</td>
      <td>0</td>
      <td>1820</td>
      <td>1</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>450000</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>40</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>...</td>
      <td>560</td>
      <td>0</td>
      <td>0</td>
      <td>19428</td>
      <td>1473</td>
      <td>560</td>
      <td>0</td>
      <td>0</td>
      <td>1128</td>
      <td>1</td>
    </tr>
    <tr>
      <th>24</th>
      <td>25</td>
      <td>90000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>-1</td>
      <td>...</td>
      <td>5398</td>
      <td>6360</td>
      <td>8292</td>
      <td>5757</td>
      <td>0</td>
      <td>5398</td>
      <td>1200</td>
      <td>2045</td>
      <td>2000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>25</th>
      <td>26</td>
      <td>50000</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>23</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>28967</td>
      <td>29829</td>
      <td>30046</td>
      <td>1973</td>
      <td>1426</td>
      <td>1001</td>
      <td>1432</td>
      <td>1062</td>
      <td>997</td>
      <td>0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>60000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>27</td>
      <td>1</td>
      <td>-2</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>-57</td>
      <td>127</td>
      <td>-189</td>
      <td>0</td>
      <td>1000</td>
      <td>0</td>
      <td>500</td>
      <td>0</td>
      <td>1000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>27</th>
      <td>28</td>
      <td>50000</td>
      <td>2</td>
      <td>3</td>
      <td>2</td>
      <td>30</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>17878</td>
      <td>18931</td>
      <td>19617</td>
      <td>1300</td>
      <td>1300</td>
      <td>1000</td>
      <td>1500</td>
      <td>1000</td>
      <td>1012</td>
      <td>0</td>
    </tr>
    <tr>
      <th>28</th>
      <td>29</td>
      <td>50000</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
      <td>47</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>2040</td>
      <td>30430</td>
      <td>257</td>
      <td>3415</td>
      <td>3421</td>
      <td>2044</td>
      <td>30430</td>
      <td>257</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29</th>
      <td>30</td>
      <td>50000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>26</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>17907</td>
      <td>18375</td>
      <td>11400</td>
      <td>1500</td>
      <td>1500</td>
      <td>1000</td>
      <td>1000</td>
      <td>1600</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>29970</th>
      <td>29971</td>
      <td>360000</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>34</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>0</td>
      <td>...</td>
      <td>49005</td>
      <td>8676</td>
      <td>19487</td>
      <td>52951</td>
      <td>64535</td>
      <td>8907</td>
      <td>53</td>
      <td>19584</td>
      <td>16080</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29971</th>
      <td>29972</td>
      <td>80000</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>36</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>69674</td>
      <td>71070</td>
      <td>73612</td>
      <td>2395</td>
      <td>2500</td>
      <td>2530</td>
      <td>2556</td>
      <td>3700</td>
      <td>3000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29972</th>
      <td>29973</td>
      <td>190000</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>37</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>29223</td>
      <td>19616</td>
      <td>148482</td>
      <td>2000</td>
      <td>3869</td>
      <td>25128</td>
      <td>10115</td>
      <td>148482</td>
      <td>4800</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29973</th>
      <td>29974</td>
      <td>230000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>35</td>
      <td>1</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>29974</th>
      <td>29975</td>
      <td>50000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>37</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>...</td>
      <td>2846</td>
      <td>1585</td>
      <td>1324</td>
      <td>0</td>
      <td>3000</td>
      <td>0</td>
      <td>0</td>
      <td>1000</td>
      <td>1000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>29975</th>
      <td>29976</td>
      <td>220000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>41</td>
      <td>0</td>
      <td>0</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>5924</td>
      <td>1759</td>
      <td>1824</td>
      <td>8840</td>
      <td>6643</td>
      <td>5924</td>
      <td>1759</td>
      <td>1824</td>
      <td>7022</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29976</th>
      <td>29977</td>
      <td>40000</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>47</td>
      <td>2</td>
      <td>2</td>
      <td>3</td>
      <td>2</td>
      <td>...</td>
      <td>51259</td>
      <td>47151</td>
      <td>46934</td>
      <td>4000</td>
      <td>0</td>
      <td>2000</td>
      <td>0</td>
      <td>3520</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>29977</th>
      <td>29978</td>
      <td>420000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>34</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>141695</td>
      <td>144839</td>
      <td>147954</td>
      <td>7000</td>
      <td>7000</td>
      <td>5500</td>
      <td>5500</td>
      <td>5600</td>
      <td>5000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29978</th>
      <td>29979</td>
      <td>310000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>39</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>219409</td>
      <td>216540</td>
      <td>210675</td>
      <td>10029</td>
      <td>9218</td>
      <td>10029</td>
      <td>8049</td>
      <td>8040</td>
      <td>10059</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29979</th>
      <td>29980</td>
      <td>180000</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>32</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29980</th>
      <td>29981</td>
      <td>50000</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>42</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>50360</td>
      <td>19971</td>
      <td>19694</td>
      <td>10000</td>
      <td>4000</td>
      <td>5000</td>
      <td>3000</td>
      <td>4500</td>
      <td>2000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29981</th>
      <td>29982</td>
      <td>50000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>44</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>...</td>
      <td>28192</td>
      <td>22676</td>
      <td>14647</td>
      <td>2300</td>
      <td>1700</td>
      <td>0</td>
      <td>517</td>
      <td>503</td>
      <td>585</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29982</th>
      <td>29983</td>
      <td>90000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>36</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>11328</td>
      <td>12036</td>
      <td>14329</td>
      <td>1500</td>
      <td>1500</td>
      <td>1500</td>
      <td>1200</td>
      <td>2500</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>29983</th>
      <td>29984</td>
      <td>20000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>44</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>...</td>
      <td>2882</td>
      <td>9235</td>
      <td>1719</td>
      <td>2890</td>
      <td>2720</td>
      <td>2890</td>
      <td>9263</td>
      <td>1824</td>
      <td>1701</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29984</th>
      <td>29985</td>
      <td>30000</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>38</td>
      <td>-1</td>
      <td>-1</td>
      <td>-2</td>
      <td>-1</td>
      <td>...</td>
      <td>1993</td>
      <td>1907</td>
      <td>3319</td>
      <td>923</td>
      <td>2977</td>
      <td>1999</td>
      <td>3057</td>
      <td>3319</td>
      <td>1000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29985</th>
      <td>29986</td>
      <td>240000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>30</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>-2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29986</th>
      <td>29987</td>
      <td>360000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>35</td>
      <td>-1</td>
      <td>-1</td>
      <td>-2</td>
      <td>-2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29987</th>
      <td>29988</td>
      <td>130000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>34</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>108047</td>
      <td>93708</td>
      <td>97353</td>
      <td>3000</td>
      <td>2000</td>
      <td>93000</td>
      <td>4000</td>
      <td>5027</td>
      <td>4005</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29988</th>
      <td>29989</td>
      <td>250000</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>34</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>245750</td>
      <td>175005</td>
      <td>179687</td>
      <td>65000</td>
      <td>8800</td>
      <td>9011</td>
      <td>6000</td>
      <td>7000</td>
      <td>6009</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29989</th>
      <td>29990</td>
      <td>150000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>35</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>780</td>
      <td>0</td>
      <td>0</td>
      <td>9054</td>
      <td>0</td>
      <td>783</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29990</th>
      <td>29991</td>
      <td>140000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>41</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>138262</td>
      <td>49675</td>
      <td>46121</td>
      <td>6000</td>
      <td>7000</td>
      <td>4228</td>
      <td>1505</td>
      <td>2000</td>
      <td>2000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29991</th>
      <td>29992</td>
      <td>210000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>34</td>
      <td>3</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>...</td>
      <td>2500</td>
      <td>2500</td>
      <td>2500</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>29992</th>
      <td>29993</td>
      <td>10000</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>43</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>-2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2000</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29993</th>
      <td>29994</td>
      <td>100000</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>38</td>
      <td>0</td>
      <td>-1</td>
      <td>-1</td>
      <td>0</td>
      <td>...</td>
      <td>70626</td>
      <td>69473</td>
      <td>55004</td>
      <td>2000</td>
      <td>111784</td>
      <td>4000</td>
      <td>3000</td>
      <td>2000</td>
      <td>2000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29994</th>
      <td>29995</td>
      <td>80000</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>34</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>...</td>
      <td>77519</td>
      <td>82607</td>
      <td>81158</td>
      <td>7000</td>
      <td>3500</td>
      <td>0</td>
      <td>7000</td>
      <td>0</td>
      <td>4000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>29995</th>
      <td>29996</td>
      <td>220000</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>39</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>88004</td>
      <td>31237</td>
      <td>15980</td>
      <td>8500</td>
      <td>20000</td>
      <td>5003</td>
      <td>3047</td>
      <td>5000</td>
      <td>1000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29996</th>
      <td>29997</td>
      <td>150000</td>
      <td>1</td>
      <td>3</td>
      <td>2</td>
      <td>43</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>-1</td>
      <td>...</td>
      <td>8979</td>
      <td>5190</td>
      <td>0</td>
      <td>1837</td>
      <td>3526</td>
      <td>8998</td>
      <td>129</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>29997</th>
      <td>29998</td>
      <td>30000</td>
      <td>1</td>
      <td>2</td>
      <td>2</td>
      <td>37</td>
      <td>4</td>
      <td>3</td>
      <td>2</td>
      <td>-1</td>
      <td>...</td>
      <td>20878</td>
      <td>20582</td>
      <td>19357</td>
      <td>0</td>
      <td>0</td>
      <td>22000</td>
      <td>4200</td>
      <td>2000</td>
      <td>3100</td>
      <td>1</td>
    </tr>
    <tr>
      <th>29998</th>
      <td>29999</td>
      <td>80000</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>41</td>
      <td>1</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>52774</td>
      <td>11855</td>
      <td>48944</td>
      <td>85900</td>
      <td>3409</td>
      <td>1178</td>
      <td>1926</td>
      <td>52964</td>
      <td>1804</td>
      <td>1</td>
    </tr>
    <tr>
      <th>29999</th>
      <td>30000</td>
      <td>50000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>46</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>36535</td>
      <td>32428</td>
      <td>15313</td>
      <td>2078</td>
      <td>1800</td>
      <td>1430</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>30000 rows × 25 columns</p>
</div>




```python
#feature engineering_remove ID
del df_credit['ID']
```


```python
df_credit.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LIMIT_BAL</th>
      <th>SEX</th>
      <th>EDUCATION</th>
      <th>MARRIAGE</th>
      <th>AGE</th>
      <th>PAY_0</th>
      <th>PAY_2</th>
      <th>PAY_3</th>
      <th>PAY_4</th>
      <th>PAY_5</th>
      <th>...</th>
      <th>BILL_AMT4</th>
      <th>BILL_AMT5</th>
      <th>BILL_AMT6</th>
      <th>PAY_AMT1</th>
      <th>PAY_AMT2</th>
      <th>PAY_AMT3</th>
      <th>PAY_AMT4</th>
      <th>PAY_AMT5</th>
      <th>PAY_AMT6</th>
      <th>default payment next month</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>20000</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>24</td>
      <td>2</td>
      <td>2</td>
      <td>-1</td>
      <td>-1</td>
      <td>-2</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>689</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>120000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>26</td>
      <td>-1</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>3272</td>
      <td>3455</td>
      <td>3261</td>
      <td>0</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>0</td>
      <td>2000</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>90000</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>34</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>14331</td>
      <td>14948</td>
      <td>15549</td>
      <td>1518</td>
      <td>1500</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>5000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>50000</td>
      <td>2</td>
      <td>2</td>
      <td>1</td>
      <td>37</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>28314</td>
      <td>28959</td>
      <td>29547</td>
      <td>2000</td>
      <td>2019</td>
      <td>1200</td>
      <td>1100</td>
      <td>1069</td>
      <td>1000</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>50000</td>
      <td>1</td>
      <td>2</td>
      <td>1</td>
      <td>57</td>
      <td>-1</td>
      <td>0</td>
      <td>-1</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>20940</td>
      <td>19146</td>
      <td>19131</td>
      <td>2000</td>
      <td>36681</td>
      <td>10000</td>
      <td>9000</td>
      <td>689</td>
      <td>679</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 24 columns</p>
</div>




```python
df_credit.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 30000 entries, 0 to 29999
    Data columns (total 24 columns):
    LIMIT_BAL                     30000 non-null int64
    SEX                           30000 non-null int64
    EDUCATION                     30000 non-null int64
    MARRIAGE                      30000 non-null int64
    AGE                           30000 non-null int64
    PAY_0                         30000 non-null int64
    PAY_2                         30000 non-null int64
    PAY_3                         30000 non-null int64
    PAY_4                         30000 non-null int64
    PAY_5                         30000 non-null int64
    PAY_6                         30000 non-null int64
    BILL_AMT1                     30000 non-null int64
    BILL_AMT2                     30000 non-null int64
    BILL_AMT3                     30000 non-null int64
    BILL_AMT4                     30000 non-null int64
    BILL_AMT5                     30000 non-null int64
    BILL_AMT6                     30000 non-null int64
    PAY_AMT1                      30000 non-null int64
    PAY_AMT2                      30000 non-null int64
    PAY_AMT3                      30000 non-null int64
    PAY_AMT4                      30000 non-null int64
    PAY_AMT5                      30000 non-null int64
    PAY_AMT6                      30000 non-null int64
    default payment next month    30000 non-null int64
    dtypes: int64(24)
    memory usage: 5.5 MB



```python
import matplotlib.pyplot as plt
```


```python
test_isnull = df_credit.isnull()
```


```python
df_credit.isnull().sum().sum()
```




    0




```python
df_credit.isnull().sum()
```




    LIMIT_BAL                     0
    SEX                           0
    EDUCATION                     0
    MARRIAGE                      0
    AGE                           0
    PAY_0                         0
    PAY_2                         0
    PAY_3                         0
    PAY_4                         0
    PAY_5                         0
    PAY_6                         0
    BILL_AMT1                     0
    BILL_AMT2                     0
    BILL_AMT3                     0
    BILL_AMT4                     0
    BILL_AMT5                     0
    BILL_AMT6                     0
    PAY_AMT1                      0
    PAY_AMT2                      0
    PAY_AMT3                      0
    PAY_AMT4                      0
    PAY_AMT5                      0
    PAY_AMT6                      0
    default payment next month    0
    dtype: int64




```python
#Exploratory Data Analysis
header = df_credit.dtypes.index
print(header)
```

    Index(['LIMIT_BAL', 'SEX', 'EDUCATION', 'MARRIAGE', 'AGE', 'PAY_0', 'PAY_2',
           'PAY_3', 'PAY_4', 'PAY_5', 'PAY_6', 'BILL_AMT1', 'BILL_AMT2',
           'BILL_AMT3', 'BILL_AMT4', 'BILL_AMT5', 'BILL_AMT6', 'PAY_AMT1',
           'PAY_AMT2', 'PAY_AMT3', 'PAY_AMT4', 'PAY_AMT5', 'PAY_AMT6',
           'default payment next month'],
          dtype='object')



```python
plt.hist(df_credit['LIMIT_BAL'])
```




    (array([1.2498e+04, 7.8800e+03, 5.0590e+03, 2.7590e+03, 1.5980e+03,
            1.2700e+02, 5.6000e+01, 2.2000e+01, 0.0000e+00, 1.0000e+00]),
     array([  10000.,  109000.,  208000.,  307000.,  406000.,  505000.,
             604000.,  703000.,  802000.,  901000., 1000000.]),
     <a list of 10 Patch objects>)




![png](output_23_1.png)



```python
#Bins 4
plt.hist(credit['LIMIT_BAL'], bins=4)
```




    (array([2.3283e+04, 6.5110e+03, 2.0000e+02, 6.0000e+00]),
     array([  10000.,  257500.,  505000.,  752500., 1000000.]),
     <a list of 4 Patch objects>)




![png](output_24_1.png)



```python
#Line Plot
plt.plot(df_credit['LIMIT_BAL'])
plt.show()
```


![png](output_25_0.png)



```python
#scatter plot
x = df_credit['PAY_0']
y = df_credit['PAY_2']
plt.scatter(x,y)
plt.show()
```


![png](output_26_0.png)



```python
#Box plots 
A = credit['BILL_AMT1']
plt.boxplot(A,0,'gD')
plt.show()
```


![png](output_27_0.png)



```python
#Correlation
CorrMat = df_credit.corr()
print(CorrMat)
```

                                LIMIT_BAL       SEX  EDUCATION  MARRIAGE  \
    LIMIT_BAL                    1.000000  0.024755  -0.219161 -0.108139   
    SEX                          0.024755  1.000000   0.014232 -0.031389   
    EDUCATION                   -0.219161  0.014232   1.000000 -0.143464   
    MARRIAGE                    -0.108139 -0.031389  -0.143464  1.000000   
    AGE                          0.144713 -0.090874   0.175061 -0.414170   
    PAY_0                       -0.271214 -0.057643   0.105364  0.019917   
    PAY_2                       -0.296382 -0.070771   0.121566  0.024199   
    PAY_3                       -0.286123 -0.066096   0.114025  0.032688   
    PAY_4                       -0.267460 -0.060173   0.108793  0.033122   
    PAY_5                       -0.249411 -0.055064   0.097520  0.035629   
    PAY_6                       -0.235195 -0.044008   0.082316  0.034345   
    BILL_AMT1                    0.285430 -0.033642   0.023581 -0.023472   
    BILL_AMT2                    0.278314 -0.031183   0.018749 -0.021602   
    BILL_AMT3                    0.283236 -0.024563   0.013002 -0.024909   
    BILL_AMT4                    0.293988 -0.021880  -0.000451 -0.023344   
    BILL_AMT5                    0.295562 -0.017005  -0.007567 -0.025393   
    BILL_AMT6                    0.290389 -0.016733  -0.009099 -0.021207   
    PAY_AMT1                     0.195236 -0.000242  -0.037456 -0.005979   
    PAY_AMT2                     0.178408 -0.001391  -0.030038 -0.008093   
    PAY_AMT3                     0.210167 -0.008597  -0.039943 -0.003541   
    PAY_AMT4                     0.203242 -0.002229  -0.038218 -0.012659   
    PAY_AMT5                     0.217202 -0.001667  -0.040358 -0.001205   
    PAY_AMT6                     0.219595 -0.002766  -0.037200 -0.006641   
    default payment next month  -0.153520 -0.039961   0.028006 -0.024339   
    
                                     AGE     PAY_0     PAY_2     PAY_3     PAY_4  \
    LIMIT_BAL                   0.144713 -0.271214 -0.296382 -0.286123 -0.267460   
    SEX                        -0.090874 -0.057643 -0.070771 -0.066096 -0.060173   
    EDUCATION                   0.175061  0.105364  0.121566  0.114025  0.108793   
    MARRIAGE                   -0.414170  0.019917  0.024199  0.032688  0.033122   
    AGE                         1.000000 -0.039447 -0.050148 -0.053048 -0.049722   
    PAY_0                      -0.039447  1.000000  0.672164  0.574245  0.538841   
    PAY_2                      -0.050148  0.672164  1.000000  0.766552  0.662067   
    PAY_3                      -0.053048  0.574245  0.766552  1.000000  0.777359   
    PAY_4                      -0.049722  0.538841  0.662067  0.777359  1.000000   
    PAY_5                      -0.053826  0.509426  0.622780  0.686775  0.819835   
    PAY_6                      -0.048773  0.474553  0.575501  0.632684  0.716449   
    BILL_AMT1                   0.056239  0.187068  0.234887  0.208473  0.202812   
    BILL_AMT2                   0.054283  0.189859  0.235257  0.237295  0.225816   
    BILL_AMT3                   0.053710  0.179785  0.224146  0.227494  0.244983   
    BILL_AMT4                   0.051353  0.179125  0.222237  0.227202  0.245917   
    BILL_AMT5                   0.049345  0.180635  0.221348  0.225145  0.242902   
    BILL_AMT6                   0.047613  0.176980  0.219403  0.222327  0.239154   
    PAY_AMT1                    0.026147 -0.079269 -0.080701  0.001295 -0.009362   
    PAY_AMT2                    0.021785 -0.070101 -0.058990 -0.066793 -0.001944   
    PAY_AMT3                    0.029247 -0.070561 -0.055901 -0.053311 -0.069235   
    PAY_AMT4                    0.021379 -0.064005 -0.046858 -0.046067 -0.043461   
    PAY_AMT5                    0.022850 -0.058190 -0.037093 -0.035863 -0.033590   
    PAY_AMT6                    0.019478 -0.058673 -0.036500 -0.035861 -0.026565   
    default payment next month  0.013890  0.324794  0.263551  0.235253  0.216614   
    
                                   PAY_5             ...              BILL_AMT4  \
    LIMIT_BAL                  -0.249411             ...               0.293988   
    SEX                        -0.055064             ...              -0.021880   
    EDUCATION                   0.097520             ...              -0.000451   
    MARRIAGE                    0.035629             ...              -0.023344   
    AGE                        -0.053826             ...               0.051353   
    PAY_0                       0.509426             ...               0.179125   
    PAY_2                       0.622780             ...               0.222237   
    PAY_3                       0.686775             ...               0.227202   
    PAY_4                       0.819835             ...               0.245917   
    PAY_5                       1.000000             ...               0.271915   
    PAY_6                       0.816900             ...               0.266356   
    BILL_AMT1                   0.206684             ...               0.860272   
    BILL_AMT2                   0.226913             ...               0.892482   
    BILL_AMT3                   0.243335             ...               0.923969   
    BILL_AMT4                   0.271915             ...               1.000000   
    BILL_AMT5                   0.269783             ...               0.940134   
    BILL_AMT6                   0.262509             ...               0.900941   
    PAY_AMT1                   -0.006089             ...               0.233012   
    PAY_AMT2                   -0.003191             ...               0.207564   
    PAY_AMT3                    0.009062             ...               0.300023   
    PAY_AMT4                   -0.058299             ...               0.130191   
    PAY_AMT5                   -0.033337             ...               0.160433   
    PAY_AMT6                   -0.023027             ...               0.177637   
    default payment next month  0.204149             ...              -0.010156   
    
                                BILL_AMT5  BILL_AMT6  PAY_AMT1  PAY_AMT2  \
    LIMIT_BAL                    0.295562   0.290389  0.195236  0.178408   
    SEX                         -0.017005  -0.016733 -0.000242 -0.001391   
    EDUCATION                   -0.007567  -0.009099 -0.037456 -0.030038   
    MARRIAGE                    -0.025393  -0.021207 -0.005979 -0.008093   
    AGE                          0.049345   0.047613  0.026147  0.021785   
    PAY_0                        0.180635   0.176980 -0.079269 -0.070101   
    PAY_2                        0.221348   0.219403 -0.080701 -0.058990   
    PAY_3                        0.225145   0.222327  0.001295 -0.066793   
    PAY_4                        0.242902   0.239154 -0.009362 -0.001944   
    PAY_5                        0.269783   0.262509 -0.006089 -0.003191   
    PAY_6                        0.290894   0.285091 -0.001496 -0.005223   
    BILL_AMT1                    0.829779   0.802650  0.140277  0.099355   
    BILL_AMT2                    0.859778   0.831594  0.280365  0.100851   
    BILL_AMT3                    0.883910   0.853320  0.244335  0.316936   
    BILL_AMT4                    0.940134   0.900941  0.233012  0.207564   
    BILL_AMT5                    1.000000   0.946197  0.217031  0.181246   
    BILL_AMT6                    0.946197   1.000000  0.199965  0.172663   
    PAY_AMT1                     0.217031   0.199965  1.000000  0.285576   
    PAY_AMT2                     0.181246   0.172663  0.285576  1.000000   
    PAY_AMT3                     0.252305   0.233770  0.252191  0.244770   
    PAY_AMT4                     0.293118   0.250237  0.199558  0.180107   
    PAY_AMT5                     0.141574   0.307729  0.148459  0.180908   
    PAY_AMT6                     0.164184   0.115494  0.185735  0.157634   
    default payment next month  -0.006760  -0.005372 -0.072929 -0.058579   
    
                                PAY_AMT3  PAY_AMT4  PAY_AMT5  PAY_AMT6  \
    LIMIT_BAL                   0.210167  0.203242  0.217202  0.219595   
    SEX                        -0.008597 -0.002229 -0.001667 -0.002766   
    EDUCATION                  -0.039943 -0.038218 -0.040358 -0.037200   
    MARRIAGE                   -0.003541 -0.012659 -0.001205 -0.006641   
    AGE                         0.029247  0.021379  0.022850  0.019478   
    PAY_0                      -0.070561 -0.064005 -0.058190 -0.058673   
    PAY_2                      -0.055901 -0.046858 -0.037093 -0.036500   
    PAY_3                      -0.053311 -0.046067 -0.035863 -0.035861   
    PAY_4                      -0.069235 -0.043461 -0.033590 -0.026565   
    PAY_5                       0.009062 -0.058299 -0.033337 -0.023027   
    PAY_6                       0.005834  0.019018 -0.046434 -0.025299   
    BILL_AMT1                   0.156887  0.158303  0.167026  0.179341   
    BILL_AMT2                   0.150718  0.147398  0.157957  0.174256   
    BILL_AMT3                   0.130011  0.143405  0.179712  0.182326   
    BILL_AMT4                   0.300023  0.130191  0.160433  0.177637   
    BILL_AMT5                   0.252305  0.293118  0.141574  0.164184   
    BILL_AMT6                   0.233770  0.250237  0.307729  0.115494   
    PAY_AMT1                    0.252191  0.199558  0.148459  0.185735   
    PAY_AMT2                    0.244770  0.180107  0.180908  0.157634   
    PAY_AMT3                    1.000000  0.216325  0.159214  0.162740   
    PAY_AMT4                    0.216325  1.000000  0.151830  0.157834   
    PAY_AMT5                    0.159214  0.151830  1.000000  0.154896   
    PAY_AMT6                    0.162740  0.157834  0.154896  1.000000   
    default payment next month -0.056250 -0.056827 -0.055124 -0.053183   
    
                                default payment next month  
    LIMIT_BAL                                    -0.153520  
    SEX                                          -0.039961  
    EDUCATION                                     0.028006  
    MARRIAGE                                     -0.024339  
    AGE                                           0.013890  
    PAY_0                                         0.324794  
    PAY_2                                         0.263551  
    PAY_3                                         0.235253  
    PAY_4                                         0.216614  
    PAY_5                                         0.204149  
    PAY_6                                         0.186866  
    BILL_AMT1                                    -0.019644  
    BILL_AMT2                                    -0.014193  
    BILL_AMT3                                    -0.014076  
    BILL_AMT4                                    -0.010156  
    BILL_AMT5                                    -0.006760  
    BILL_AMT6                                    -0.005372  
    PAY_AMT1                                     -0.072929  
    PAY_AMT2                                     -0.058579  
    PAY_AMT3                                     -0.056250  
    PAY_AMT4                                     -0.056827  
    PAY_AMT5                                     -0.055124  
    PAY_AMT6                                     -0.053183  
    default payment next month                    1.000000  
    
    [24 rows x 24 columns]



```python
covMat = credit.cov()
print(covMat)
```

                                   LIMIT_BAL          SEX     EDUCATION  \
    LIMIT_BAL                   1.683446e+10  1571.050630 -22474.028945   
    SEX                         1.571051e+03     0.239247      0.005502   
    EDUCATION                  -2.247403e+04     0.005502      0.624651   
    MARRIAGE                   -7.323670e+03    -0.008014     -0.059184   
    AGE                         1.730767e+05    -0.409726      1.275380   
    PAY_0                      -3.954593e+04    -0.031685      0.093584   
    PAY_2                      -4.603765e+04    -0.041442      0.115025   
    PAY_3                      -4.443225e+04    -0.038694      0.107861   
    PAY_4                      -4.057181e+04    -0.034411      0.100528   
    PAY_5                      -3.667056e+04    -0.030521      0.087340   
    PAY_6                      -3.509308e+04    -0.024754      0.074816   
    BILL_AMT1                   2.727020e+09 -1211.694332   1372.377644   
    BILL_AMT2                   2.570130e+09 -1085.595467   1054.657595   
    BILL_AMT3                   2.548533e+09  -833.207432    712.664124   
    BILL_AMT4                   2.453926e+09  -688.489572    -22.948827   
    BILL_AMT5                   2.331481e+09  -505.694333   -363.577664   
    BILL_AMT6                   2.243837e+09  -487.430160   -428.274232   
    PAY_AMT1                    4.195711e+08    -1.964266   -490.330155   
    PAY_AMT2                    5.333504e+08   -15.675500   -547.005021   
    PAY_AMT3                    4.801180e+08   -74.034812   -555.834305   
    PAY_AMT4                    4.131202e+08   -17.080110   -473.206951   
    PAY_AMT5                    4.305657e+08   -12.458809   -487.335947   
    PAY_AMT6                    5.065153e+08   -24.051885   -522.673379   
    default payment next month -8.267552e+03    -0.008113      0.009187   
    
                                   MARRIAGE            AGE         PAY_0  \
    LIMIT_BAL                  -7323.669658  173076.722569 -39545.930009   
    SEX                           -0.008014      -0.409726     -0.031685   
    EDUCATION                     -0.059184       1.275380      0.093584   
    MARRIAGE                       0.272452      -1.992764      0.011683   
    AGE                           -1.992764      84.969755     -0.408639   
    PAY_0                          0.011683      -0.408639      1.262930   
    PAY_2                          0.015122      -0.553408      0.904330   
    PAY_3                          0.020421      -0.585263      0.772384   
    PAY_4                          0.020213      -0.535851      0.707972   
    PAY_5                          0.021074      -0.562245      0.648743   
    PAY_6                          0.020616      -0.517022      0.613292   
    BILL_AMT1                   -902.154685   38172.933546  15480.304170   
    BILL_AMT2                   -802.517866   35613.657962  15185.916919   
    BILL_AMT3                   -901.679085   34334.251320  14011.556537   
    BILL_AMT4                   -783.881599   30453.108180  12950.248389   
    BILL_AMT5                   -805.840875   27654.067800  12341.668685   
    BILL_AMT6                   -659.223347   26137.648547  11844.759724   
    PAY_AMT1                     -51.691615    3992.041735  -1475.495089   
    PAY_AMT2                     -97.327974    4626.861549  -1815.138407   
    PAY_AMT3                     -32.546082    4746.824393  -1396.168258   
    PAY_AMT4                    -103.518204    3087.324192  -1126.847945   
    PAY_AMT5                      -9.607709    3218.052172   -999.107730   
    PAY_AMT6                     -61.623271    3191.903901  -1172.193614   
    default payment next month    -0.005273       0.053143      0.151499   
    
                                       PAY_2         PAY_3         PAY_4  \
    LIMIT_BAL                  -46037.648360 -44432.253315 -40571.811859   
    SEX                            -0.041442     -0.038694     -0.034411   
    EDUCATION                       0.115025      0.107861      0.100528   
    MARRIAGE                        0.015122      0.020421      0.020213   
    AGE                            -0.553408     -0.585263     -0.535851   
    PAY_0                           0.904330      0.772384      0.707972   
    PAY_2                           1.433254      1.098371      0.926680   
    PAY_3                           1.098371      1.432492      1.087761   
    PAY_4                           0.926680      1.087761      1.366885   
    PAY_5                           0.844886      0.931455      1.086161   
    PAY_6                           0.792320      0.870815      0.963263   
    BILL_AMT1                   20706.614217  18373.210469  17460.198259   
    BILL_AMT2                   20045.829482  20214.071495  18790.627741   
    BILL_AMT3                   18609.510991  18882.491544  19862.999426   
    BILL_AMT4                   17116.298983  17494.100555  18496.423186   
    BILL_AMT5                   16110.952468  16382.947539  17265.551898   
    BILL_AMT6                   15642.875812  15847.089648  16651.586314   
    PAY_AMT1                    -1600.240756     25.668468   -181.295613   
    PAY_AMT2                    -1627.192336  -1841.952825    -52.358166   
    PAY_AMT3                    -1178.331282  -1123.428782  -1425.205189   
    PAY_AMT4                     -878.843879   -863.762183   -796.035739   
    PAY_AMT5                     -678.468530   -655.796002   -599.991629   
    PAY_AMT6                     -776.835035   -763.026041   -552.137338   
    default payment next month      0.130960      0.116867      0.105115   
    
                                       PAY_5             ...              \
    LIMIT_BAL                  -36670.562325             ...               
    SEX                            -0.030521             ...               
    EDUCATION                       0.087340             ...               
    MARRIAGE                        0.021074             ...               
    AGE                            -0.562245             ...               
    PAY_0                           0.648743             ...               
    PAY_2                           0.844886             ...               
    PAY_3                           0.931455             ...               
    PAY_4                           1.086161             ...               
    PAY_5                           1.284114             ...               
    PAY_6                           1.064545             ...               
    BILL_AMT1                   17246.377531             ...               
    BILL_AMT2                   18301.285286             ...               
    BILL_AMT3                   19122.663330             ...               
    BILL_AMT4                   19822.925512             ...               
    BILL_AMT5                   18586.590324             ...               
    BILL_AMT6                   17715.690075             ...               
    PAY_AMT1                     -114.281714             ...               
    PAY_AMT2                      -83.324487             ...               
    PAY_AMT3                      180.812142             ...               
    PAY_AMT4                    -1034.961970             ...               
    PAY_AMT5                     -577.161017             ...               
    PAY_AMT6                     -463.892613             ...               
    default payment next month      0.096020             ...               
    
                                   BILL_AMT4     BILL_AMT5     BILL_AMT6  \
    LIMIT_BAL                   2.453926e+09  2.331481e+09  2.243837e+09   
    SEX                        -6.884896e+02 -5.056943e+02 -4.874302e+02   
    EDUCATION                  -2.294883e+01 -3.635777e+02 -4.282742e+02   
    MARRIAGE                   -7.838816e+02 -8.058409e+02 -6.592233e+02   
    AGE                         3.045311e+04  2.765407e+04  2.613765e+04   
    PAY_0                       1.295025e+04  1.234167e+04  1.184476e+04   
    PAY_2                       1.711630e+04  1.611095e+04  1.564288e+04   
    PAY_3                       1.749410e+04  1.638295e+04  1.584709e+04   
    PAY_4                       1.849642e+04  1.726555e+04  1.665159e+04   
    PAY_5                       1.982293e+04  1.858659e+04  1.771569e+04   
    PAY_6                       1.970555e+04  2.033812e+04  1.952488e+04   
    BILL_AMT1                   4.075286e+09  3.714795e+09  3.519876e+09   
    BILL_AMT2                   4.086508e+09  3.720401e+09  3.524868e+09   
    BILL_AMT3                   4.122238e+09  3.726780e+09  3.524247e+09   
    BILL_AMT4                   4.138716e+09  3.677105e+09  3.451762e+09   
    BILL_AMT5                   3.677105e+09  3.696294e+09  3.425914e+09   
    BILL_AMT6                   3.451762e+09  3.425914e+09  3.546692e+09   
    PAY_AMT1                    2.482888e+08  2.185501e+08  1.972478e+08   
    PAY_AMT2                    3.076686e+08  2.538936e+08  2.369244e+08   
    PAY_AMT3                    3.398374e+08  2.700805e+08  2.451233e+08   
    PAY_AMT4                    1.312133e+08  2.791830e+08  2.334670e+08   
    PAY_AMT5                    1.576892e+08  1.315051e+08  2.799982e+08   
    PAY_AMT6                    2.031590e+08  1.774537e+08  1.222761e+08   
    default payment next month -2.711999e+02 -1.705974e+02 -1.327963e+02   
    
                                    PAY_AMT1      PAY_AMT2      PAY_AMT3  \
    LIMIT_BAL                   4.195711e+08  5.333504e+08  4.801180e+08   
    SEX                        -1.964266e+00 -1.567550e+01 -7.403481e+01   
    EDUCATION                  -4.903302e+02 -5.470050e+02 -5.558343e+02   
    MARRIAGE                   -5.169161e+01 -9.732797e+01 -3.254608e+01   
    AGE                         3.992042e+03  4.626862e+03  4.746824e+03   
    PAY_0                      -1.475495e+03 -1.815138e+03 -1.396168e+03   
    PAY_2                      -1.600241e+03 -1.627192e+03 -1.178331e+03   
    PAY_3                       2.566847e+01 -1.841953e+03 -1.123429e+03   
    PAY_4                      -1.812956e+02 -5.235817e+01 -1.425205e+03   
    PAY_5                      -1.142817e+02 -8.332449e+01  1.808121e+02   
    PAY_6                      -2.850067e+01 -1.383995e+02  1.181210e+02   
    BILL_AMT1                   1.710894e+08  1.685692e+08  2.034048e+08   
    BILL_AMT2                   3.305146e+08  1.653859e+08  1.888731e+08   
    BILL_AMT3                   2.806565e+08  5.064226e+08  1.587478e+08   
    BILL_AMT4                   2.482888e+08  3.076686e+08  3.398374e+08   
    BILL_AMT5                   2.185501e+08  2.538936e+08  2.700805e+08   
    BILL_AMT6                   1.972478e+08  2.369244e+08  2.451233e+08   
    PAY_AMT1                    2.743423e+08  1.089849e+08  7.354626e+07   
    PAY_AMT2                    1.089849e+08  5.308817e+08  9.929841e+07   
    PAY_AMT3                    7.354626e+07  9.929841e+07  3.100051e+08   
    PAY_AMT4                    5.178189e+07  6.501168e+07  5.966970e+07   
    PAY_AMT5                    3.756893e+07  6.368414e+07  4.282921e+07   
    PAY_AMT6                    5.469033e+07  6.456816e+07  5.093879e+07   
    default payment next month -5.013746e+02 -5.602107e+02 -4.110763e+02   
    
                                    PAY_AMT4      PAY_AMT5      PAY_AMT6  \
    LIMIT_BAL                   4.131202e+08  4.305657e+08  5.065153e+08   
    SEX                        -1.708011e+01 -1.245881e+01 -2.405188e+01   
    EDUCATION                  -4.732070e+02 -4.873359e+02 -5.226734e+02   
    MARRIAGE                   -1.035182e+02 -9.607709e+00 -6.162327e+01   
    AGE                         3.087324e+03  3.218052e+03  3.191904e+03   
    PAY_0                      -1.126848e+03 -9.991077e+02 -1.172194e+03   
    PAY_2                      -8.788439e+02 -6.784685e+02 -7.768350e+02   
    PAY_3                      -8.637622e+02 -6.557960e+02 -7.630260e+02   
    PAY_4                      -7.960357e+02 -5.999916e+02 -5.521373e+02   
    PAY_5                      -1.034962e+03 -5.771610e+02 -4.638926e+02   
    PAY_6                       3.426237e+02 -8.158327e+02 -5.172163e+02   
    BILL_AMT1                   1.826164e+08  1.879091e+08  2.347681e+08   
    BILL_AMT2                   1.643518e+08  1.717652e+08  2.204845e+08   
    BILL_AMT3                   1.558003e+08  1.904126e+08  2.247817e+08   
    BILL_AMT4                   1.312133e+08  1.576892e+08  2.031590e+08   
    BILL_AMT5                   2.791830e+08  1.315051e+08  1.774537e+08   
    BILL_AMT6                   2.334670e+08  2.799982e+08  1.222761e+08   
    PAY_AMT1                    5.178189e+07  3.756893e+07  5.469033e+07   
    PAY_AMT2                    6.501168e+07  6.368414e+07  6.456816e+07   
    PAY_AMT3                    5.966970e+07  4.282921e+07  5.093879e+07   
    PAY_AMT4                    2.454286e+08  3.634098e+07  4.395747e+07   
    PAY_AMT5                    3.634098e+07  2.334266e+08  4.207110e+07   
    PAY_AMT6                    4.395747e+07  4.207110e+07  3.160383e+08   
    default payment next month -3.695159e+02 -3.495625e+02 -3.924264e+02   
    
                                default payment next month  
    LIMIT_BAL                                 -8267.551759  
    SEX                                          -0.008113  
    EDUCATION                                     0.009187  
    MARRIAGE                                     -0.005273  
    AGE                                           0.053143  
    PAY_0                                         0.151499  
    PAY_2                                         0.130960  
    PAY_3                                         0.116867  
    PAY_4                                         0.105115  
    PAY_5                                         0.096020  
    PAY_6                                         0.089194  
    BILL_AMT1                                  -600.394108  
    BILL_AMT2                                  -419.289137  
    BILL_AMT3                                  -405.153680  
    BILL_AMT4                                  -271.199885  
    BILL_AMT5                                  -170.597447  
    BILL_AMT6                                  -132.796294  
    PAY_AMT1                                   -501.374552  
    PAY_AMT2                                   -560.210740  
    PAY_AMT3                                   -411.076284  
    PAY_AMT4                                   -369.515887  
    PAY_AMT5                                   -349.562530  
    PAY_AMT6                                   -392.426415  
    default payment next month                    0.172276  
    
    [24 rows x 24 columns]



```python
import matplotlib as mpl
import matplotlib.pyplot as plt
```


```python
#Correlation to csv for analysis
correlation = pd.DataFrame(CorrMat)
correlation.to_csv("C:\⁨Desktop⁩.csv")
print(correlation)
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    <ipython-input-10-124298572c0f> in <module>
          1 #Correlation to csv for analysis
    ----> 2 correlation = pd.DataFrame(CorrMat)
          3 correlation.to_csv("C:\⁨Desktop⁩.csv")
          4 print(correlation)


    NameError: name 'CorrMat' is not defined



```python
#EDA Distribution
# Distribution of age, with an overlay of a density plot
import seaborn as sns
age = credit['AGE'].dropna()
age_dist = sns.distplot(age)
age_dist.set_title("age")
```

    /Users/timwilson/anaconda3/lib/python3.6/site-packages/scipy/stats/stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval





    Text(0.5,1,'age')




![png](output_32_2.png)



```python
#Distribution by education
ed = credit['EDUCATION'].dropna()
ed_dist = sns.distplot(ed)
ed_dist.set_title("Education")
```




    Text(0.5,1,'Education')




![png](output_33_1.png)



```python
#Distribution by Defaulty
default = credit['default payment next month'].dropna()
def_dist = sns.distplot(default)
def_dist.set_title("Default")
```




    Text(0.5,1,'Default')




![png](output_34_1.png)



```python
#Visualize Correlation Matri
import matplotlib.pyplot as plt
plt.matshow(correlation)
```




    <matplotlib.image.AxesImage at 0x1a19026860>




![png](output_35_1.png)



```python
credit.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 30000 entries, 0 to 29999
    Data columns (total 24 columns):
    LIMIT_BAL                     30000 non-null int64
    SEX                           30000 non-null int64
    EDUCATION                     30000 non-null int64
    MARRIAGE                      30000 non-null int64
    AGE                           30000 non-null int64
    PAY_0                         30000 non-null int64
    PAY_2                         30000 non-null int64
    PAY_3                         30000 non-null int64
    PAY_4                         30000 non-null int64
    PAY_5                         30000 non-null int64
    PAY_6                         30000 non-null int64
    BILL_AMT1                     30000 non-null int64
    BILL_AMT2                     30000 non-null int64
    BILL_AMT3                     30000 non-null int64
    BILL_AMT4                     30000 non-null int64
    BILL_AMT5                     30000 non-null int64
    BILL_AMT6                     30000 non-null int64
    PAY_AMT1                      30000 non-null int64
    PAY_AMT2                      30000 non-null int64
    PAY_AMT3                      30000 non-null int64
    PAY_AMT4                      30000 non-null int64
    PAY_AMT5                      30000 non-null int64
    PAY_AMT6                      30000 non-null int64
    default payment next month    30000 non-null int64
    dtypes: int64(24)
    memory usage: 5.5 MB



```python
#convert to csv
df_credit.to_csv("C:\⁨Desktop⁩.csv")
```


```python
#Regression ##estimators
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn import linear_model
```


```python
#model metrics
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from sklearn.model_selection import cross_val_score
```


```python
#cross validation
from sklearn.model_selection import train_test_split
```


```python
#features
features = df_credit.iloc[:,12:23]
print('Summary of feature sample')
features.head()
```

    Summary of feature sample





<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>BILL_AMT2</th>
      <th>BILL_AMT3</th>
      <th>BILL_AMT4</th>
      <th>BILL_AMT5</th>
      <th>BILL_AMT6</th>
      <th>PAY_AMT1</th>
      <th>PAY_AMT2</th>
      <th>PAY_AMT3</th>
      <th>PAY_AMT4</th>
      <th>PAY_AMT5</th>
      <th>PAY_AMT6</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3102</td>
      <td>689</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>689</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1725</td>
      <td>2682</td>
      <td>3272</td>
      <td>3455</td>
      <td>3261</td>
      <td>0</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>0</td>
      <td>2000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>14027</td>
      <td>13559</td>
      <td>14331</td>
      <td>14948</td>
      <td>15549</td>
      <td>1518</td>
      <td>1500</td>
      <td>1000</td>
      <td>1000</td>
      <td>1000</td>
      <td>5000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>48233</td>
      <td>49291</td>
      <td>28314</td>
      <td>28959</td>
      <td>29547</td>
      <td>2000</td>
      <td>2019</td>
      <td>1200</td>
      <td>1100</td>
      <td>1069</td>
      <td>1000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5670</td>
      <td>35835</td>
      <td>20940</td>
      <td>19146</td>
      <td>19131</td>
      <td>2000</td>
      <td>36681</td>
      <td>10000</td>
      <td>9000</td>
      <td>689</td>
      <td>679</td>
    </tr>
  </tbody>
</table>
</div>




```python
features.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 30000 entries, 0 to 29999
    Data columns (total 11 columns):
    BILL_AMT2    30000 non-null int64
    BILL_AMT3    30000 non-null int64
    BILL_AMT4    30000 non-null int64
    BILL_AMT5    30000 non-null int64
    BILL_AMT6    30000 non-null int64
    PAY_AMT1     30000 non-null int64
    PAY_AMT2     30000 non-null int64
    PAY_AMT3     30000 non-null int64
    PAY_AMT4     30000 non-null int64
    PAY_AMT5     30000 non-null int64
    PAY_AMT6     30000 non-null int64
    dtypes: int64(11)
    memory usage: 2.5 MB



```python
#dependent variable
depVar = df_credit['PAY_AMT6']
```


```python
#Training Set (Feature Space: X Training)
X_train = (features[: 21000])
X_train.head()
X_train.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 21000 entries, 0 to 20999
    Data columns (total 11 columns):
    BILL_AMT2    21000 non-null int64
    BILL_AMT3    21000 non-null int64
    BILL_AMT4    21000 non-null int64
    BILL_AMT5    21000 non-null int64
    BILL_AMT6    21000 non-null int64
    PAY_AMT1     21000 non-null int64
    PAY_AMT2     21000 non-null int64
    PAY_AMT3     21000 non-null int64
    PAY_AMT4     21000 non-null int64
    PAY_AMT5     21000 non-null int64
    PAY_AMT6     21000 non-null int64
    dtypes: int64(11)
    memory usage: 1.8 MB



```python
#Dependent Variable Training Set (y Training)
y_train = depVar[: 21000]
y_train_count = len(y_train.index)
print('The number of observations in the Y training set are:',str(y_train_count))
y_train.head()
```

    The number of observations in the Y training set are: 21000





    0       0
    1    2000
    2    5000
    3    1000
    4     679
    Name: PAY_AMT6, dtype: int64




```python
#Testing Set (X Testing)
X_test = features[-100:]
X_test_count = len(X_test.index)
print('The number of observations in the feature testing set is:',str(X_test_count))
print(X_test.head())
```

    The number of observations in the feature testing set is: 100
           BILL_AMT2  BILL_AMT3  BILL_AMT4  BILL_AMT5  BILL_AMT6  PAY_AMT1  \
    29900          0          0          0          0          0         0   
    29901      48750     103486      50590      50248      49387         0   
    29902     168088     168955     161351     126198     124746    168096   
    29903      17082      13333         99         99     172104     10018   
    29904      56021      54126      58732      59306      59728      2600   
    
           PAY_AMT2  PAY_AMT3  PAY_AMT4  PAY_AMT5  PAY_AMT6  
    29900         0         0         0         0         0  
    29901      6556      3250      1563      1208       781  
    29902      6409      7335      4448      4519      5003  
    29903     13333        99        99    172104     30013  
    29904      4553      5800      2000      1000      1462  



```python
X_train, X_test, y_train, y_test = train_test_split(X_train, y_train)
```


```python
X_train.shape, X_test.shape
```




    ((15750, 11), (5250, 11))




```python
X_train, X_test, y_train, y_test = train_test_split(X_train, y_train)
X_train.shape, X_test.shape
```




    ((11812, 11), (3938, 11))




```python
from sklearn.model_selection import cross_val_score
```


```python
#Linearmodel
LMmodel10 = LinearRegression(n_jobs=10)
LMmodel10.fit (X_train,y_train)
print(cross_val_score(LMmodel10, X_train, y_train)) 
LMmodel10.score(X_train,y_train)
```


```python
#Linear Regression 10 jobs
modelLR = LinearRegression()
modelLR.fit(X_train,y_train)
print(cross_val_score(modelLR, X_train, y_train)) 
modelLR.score(X_train,y_train)
```


```python
#RF Model
#Model Fitting
modelRF = RandomForestRegressor(max_depth=2, random_state=0, n_estimators=100)
modelRF.fit(X_train,y_train)
```




    RandomForestRegressor(bootstrap=True, criterion='mse', max_depth=2,
               max_features='auto', max_leaf_nodes=None,
               min_impurity_decrease=0.0, min_impurity_split=None,
               min_samples_leaf=1, min_samples_split=2,
               min_weight_fraction_leaf=0.0, n_estimators=100, n_jobs=None,
               oob_score=False, random_state=0, verbose=0, warm_start=False)




```python
#RF Fit and Cross Val
print(cross_val_score(modelRF, X_train, y_train))
modelRF.score(X_train,y_train)
```

    /Users/timwilson/anaconda3/lib/python3.6/site-packages/sklearn/model_selection/_split.py:2053: FutureWarning: You should specify a value for 'cv' instead of relying on the default value. The default value will change from 3 to 5 in version 0.22.
      warnings.warn(CV_WARNING, FutureWarning)


    [0.90849609 0.82366995 0.94081304]





    0.9067270957400327




```python
#Support Vector Machine
modelSVR = SVR()
modelSVR.fit(X_train,y_train)
print(cross_val_score(modelSVR, X_train, y_train)) 
modelSVR.score(X_train,y_train)
```

    /Users/timwilson/anaconda3/lib/python3.6/site-packages/sklearn/svm/base.py:196: FutureWarning: The default value of gamma will change from 'auto' to 'scale' in version 0.22 to account better for unscaled features. Set gamma explicitly to 'auto' or 'scale' to avoid this warning.
      "avoid this warning.", FutureWarning)
    /Users/timwilson/anaconda3/lib/python3.6/site-packages/sklearn/model_selection/_split.py:2053: FutureWarning: You should specify a value for 'cv' instead of relying on the default value. The default value will change from 3 to 5 in version 0.22.
      warnings.warn(CV_WARNING, FutureWarning)
    /Users/timwilson/anaconda3/lib/python3.6/site-packages/sklearn/svm/base.py:196: FutureWarning: The default value of gamma will change from 'auto' to 'scale' in version 0.22 to account better for unscaled features. Set gamma explicitly to 'auto' or 'scale' to avoid this warning.
      "avoid this warning.", FutureWarning)
    /Users/timwilson/anaconda3/lib/python3.6/site-packages/sklearn/svm/base.py:196: FutureWarning: The default value of gamma will change from 'auto' to 'scale' in version 0.22 to account better for unscaled features. Set gamma explicitly to 'auto' or 'scale' to avoid this warning.
      "avoid this warning.", FutureWarning)
    /Users/timwilson/anaconda3/lib/python3.6/site-packages/sklearn/svm/base.py:196: FutureWarning: The default value of gamma will change from 'auto' to 'scale' in version 0.22 to account better for unscaled features. Set gamma explicitly to 'auto' or 'scale' to avoid this warning.
      "avoid this warning.", FutureWarning)


    [-0.0479897  -0.04136718 -0.04993176]





    -0.04538140060441065




```python
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
```


```python
from math import sqrt
```


```python
#Prediction using RF Model
#Make Predictions
predictions = modelRF.predict(X_test)
predRsquared = r2_score(y_test,predictions)
rmse = sqrt(mean_squared_error(y_test, predictions))
print('R Squared: %.3f' % predRsquared)
print('RMSE: %.3f' % rmse)
```

    R Squared: 0.950
    RMSE: 3774.700



```python
#Plot Prediction
plt.scatter(y_test, predictions, color=['blue','green'], alpha = 0.5)
plt.xlabel('Ground Truth')
plt.ylabel('Predictions')
plt.show();
```


![png](output_59_0.png)



```python

```
